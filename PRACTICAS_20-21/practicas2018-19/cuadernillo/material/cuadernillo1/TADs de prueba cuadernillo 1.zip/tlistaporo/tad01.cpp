#include <iostream>

using namespace std;

#include "tlistaporo.h"

int
main(void)
{
  TPoro a, b, c;
  TListaPoro d, e, f;

  cout << "No hace nada" << endl;
}
