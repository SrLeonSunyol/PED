#include <iostream>

using namespace std;

#include "tlistaporo.h"

int
main(void)
{
  TListaPoro a;

  cout << a << endl;
}
