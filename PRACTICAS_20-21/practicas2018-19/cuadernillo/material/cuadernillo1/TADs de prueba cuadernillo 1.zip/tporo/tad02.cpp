#include <iostream>

using namespace std;

#include "tporo.h"

int
main(void)
{
  TPoro a;

  cout << a << endl;
}
