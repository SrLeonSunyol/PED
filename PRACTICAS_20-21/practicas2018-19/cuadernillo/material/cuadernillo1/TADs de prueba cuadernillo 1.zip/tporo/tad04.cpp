#include <iostream>

using namespace std;

#include "tporo.h"

int
main(void)
{
  TPoro a;

  a.Posicion(10, 20);

  cout << a << endl;
}
